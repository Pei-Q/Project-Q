$(function(){
   

    $('.btn').on('click',function(){
        var _username = $('#username').val();
        var _password = $('#password').val();
            // 发起ajax请求
            $.ajax({
                url:'../lib/login.php',
                data:{
                    username:_username,
                    password:_password
                },
                success:function(data){
                    if(data === 'ok'){
                        console.log('成功');
                        location.href = '../index.html';     
                    }else if(data === 'fail'){
                        alert('用户名或者密码错误，请重新登陆。');
                          return;           
                    }
                    
                }
            })  
    });
})