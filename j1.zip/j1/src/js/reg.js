$(function(){
    var $username = $('.username');
    var $code = $('.code');


    var $confirmbtn=$('.confirmbtn');
    //console.log($confirmbtn)
    
    //var $license = $('#license').val();
    var $btn = $('.btn');
    //var $zc = $('.zc');
    var $phint = $('.phint');
    var $pswhint = $('.pswhint');
    //var $phuan = $('.phuan');
    //var $pswhuan = $('.pswhuan');
    var password = /^\w{6,20}$/g;
    var phonenum =/^1[34578]\d{9}$/i;
    // 验证码
    function vCode(){
        var res = '';
        for(var i=0;i<4;i++){
            var code = parseInt(Math.random()*10);
            res+=code;//console.log(res)
        }
        $code.html(res);//.html等同于原生js中的innerhtml
        //console.log($code.text())
    }

    vCode();


    
    function confirmyz(){
            var $importCode = $('.importCode').val();
            if($importCode==='' ){
               $('.yzhint').css({display:'block'});

            }else{
                $('.yzhint').css({display:'none'});
            }
            if($importCode!=$('.code').text()){
                $('.yzhint').css({display:'block'});
            }
           
        }
    $confirmbtn .on('click', function(){
        confirmyz();
       
    });

    $username .on('focus',function(){
       $username.val('');

    }).on('blur',function(){
        $username = $('.username').val();
        //console.log($username);
        if($username===''){
            $phint.css({display:'block'});
            $phint.html('用户不能为空');
            
        }
        if(!phonenum.test($username)){
            $phint.css({display:'block'});
            $phint.html('请输入正确的手机！');
            
        }else{
            $phint.css({display:'none'});
            $phint.html();
        }
    });


    var $zhuce_l=$('zhuce_l');
    var $psw1=$('.psw1');
    var $psw2=$('.psw2');
    

    $psw1.on('focus',function(){
        $psw1.val('');
    }).on('blur',function(){
        if($psw1.val()===''){
            $pswhint.css({display:'block'})
            $pswhint.html('您输入的密码不能为空')
        }
        if(!password.test($psw1.val())){
            $pswhint.css({display:'block'})
            $pswhint.html('您输入的密码不能小于4个字符！')
        }
    });

     $psw2.on('blur',function(){
        if($('.psd2').val()===''){
            $pswhint.css({display:'block'})
            $pswhint.html('请再次输入密码！');
        }else{
            if($('.psw1').val()!=$('.psw2').val()){
                $pswhint.css({display:'block'})
                $pswhint.html('两次密码输入不一致，请重新输入！');
                $('.psd2').val('');
                return;
            }else{
                
                $pswhint.css({display:'none'})
            }
        }
    });


    




    $btn.on('click',function(){
        if($('#username').val()!='' && $('#psd2').val()!=''&& $('.importCode').val()==$('.code').text()){
            var _username = $('#username').val();
            var _password = $('#psd2').val();
                // 发起ajax请求
                $.ajax({
                    url:'../api/reg.php',
                    data:{
                        username:_username,
                        password:_password
                    },
                    success:function(data){
                        if(data === 'fail'){
                            $hint.css({display:'block'});
                            $hint.html('用户名已经被占用');
                            return;
                        }
                        
                        location.href = '../html/login.html';
                    }
                })     
            }else{
                alert('请按要求注册');
                return;
            }
    })
})