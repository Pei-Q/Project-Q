$(function(){
        var goods_pic = document.querySelector('.goods-pic');
        //获取传递过来的参数
        var params = location.search;//'?id=g001'
        params = params.slice(1);
        console.log(params)
        params = params.split('=');
        // console.log(params);
        var _id = params[1];
        // console.log(_id)
        var status = [200,304];
        var xhr = new XMLHttpRequest();
        xhr.onload = function(){
            if(status.includes(xhr.status)){
                var res = JSON.parse(xhr.responseText);
                console.log(res);
                var zhutu = document.createElement('div');
                var attr = [(res[_id])];
                //console.log(attr)
                var prices;
                attr.map(function(item){
                        console.log(item)
                        //prices=item.discount;
                        //var sheng = (item.discount)-(item.price);
                        zhutu.innerHTML= `<img src="${(item.imgurl)}"/>`;
                        
                }).join('')       
                goods_pic.appendChild(zhutu);
                var size,color,attr;
                
         
                $('.chima_t').on('click','li',function(){
                    $('.chima_t').find('li').css({border:'1px solid #ccc'});
                    $(this).css({border:'2px solid #f90'});
                   /* size=$(this).text();*/
                });
                $('.chima_c').on('click','img',function(){
                    $('.chima_c').find('img').css({border:'1px solid #ccc',width:100,height:30});
                    $(this).css({border:'2px solid #f90',width:100,height:30});
                    
                });
                $('.xiaotu').on('click','li',function(){
                    $('.goods-pic').find('img').remove();
                    var copyimg = $(this).find('img').clone();
                    copyimg.appendTo($('.goods-pic'));
                    $('.goods-pic').find('img').css({
                        width:430,
                        height:430,
                    });
                    $('.xiaotu').find('img').css({border:'1px solid #e9e9e9'});
                    $(this).find('img').css({border:'2px solid #f60'});
                });
                $('.jia').on('click',function(){
                    var attr = ($('.chima_b').find('input').val())*1;
                    attr+=1;
                    $('.chima_b').find('input').val(attr);
                });
                $('.jian').on('click',function(){
                    attr = ($('.chima_b').find('input').val())*1;
                    attr-=1;
                    if(attr<1){
                        attr=1;
                    }
                    $('.chima_b').find('input').val(attr);
                });
                //点击立即购买跳转购物车
                $('.btn-fastbuy').on('click',function(){
                    location.href = '../html/car.html';
                });

                //点击加购
                $('.btn-buy').on('click',function(){
                    var number = $('.chima_b').find('input').val();
                   
                    if(!number){
                        alert('数量')
                        return;
                    }
                   
                    var $copyImg = $('.goods-pic').find('img').clone();
                    var $img = $('.goods-pic').find('img');
                    // 定位复制的图片到当前图片位置
                    $copyImg.css({
                        position:'absolute',
                        left:$img.offset().left,
                        top:$img.offset().top,
                        width:$img.width(),
                        height:$img.height()
                    });
                    // 把复制的图片写入页面
                    // 建议写到body
                    $copyImg.appendTo('body');
                    $copyImg.animate({
                        left:$('.shopping_l').offset().left-(window.innerWidth - document.body.clientWidth)-37,
                        top:$('.spc').height + 97,
                        width:83,
                        height:75
                    },function(){
                        //动画完成
                        // 删除复制的图片
                        $copyImg.remove();

                        var $copyImgg = $('.goods-pic').find('img').clone();
                        $copyImgg.css({
                            width:83,
                            height:75
                        })

                        var _imgs = $('.goods-pic').find('img').attr('src');
                        var _price = attr[0].discount;
                        var _headline = $('.goodsname').text();
                        var _number = $('.chima_b').find('input').val();
                        var _color = color;
                         // 用于保存购物车中的商品信息
                        var carlist = [];
                        var cookies = document.cookie;
                        if(cookies.length){
                            cookies = cookies.split('; ');//['carlist=[{},{}]','username=xxx']
                            cookies.forEach(function(item){
                                var arr = item.split('=');
                                if(arr[0] === 'carlist'){
                                    carlist = JSON.parse(arr[1]);
                                }
                            });
                        }     

                        var currentLi = $('.spcImg').find('li');
                        // 获取当前商品的id
                        var guid = attr[0].id;

                        

                        //判断carlist中是否存在相同商品
                        //判断循环是否跑完
                        for(var i=0;i<carlist.length;i++){
                            if(carlist[i].guid === guid){
                                break;
                            }
                        }

                        if(i===carlist.length){
                            //不存在：创建对象，并且数量为1
                            var goods = {
                                guid:guid,
                                imgs:_imgs,
                                name:_price,
                                headline:_headline,
                                number:_number,
                                color:_color,
                                qty:1
                            }
                            carlist.push(goods);
                            
                        }else{
                            //存在：数量+1
                            carlist[i].qty++;
                        }


                        // 写入cookie
                        document.cookie = 'carlist=' + JSON.stringify(carlist);
                    });
                    
                });
                    
                $('.shopping').on('click','ul li',function(){
                    var $this =$(this);
                    if ($this.attr('status') === '1') {
                        if($('.shopping').css('right')!='0px'){
                            $('.shopping').animate({right:0})
                        }else{
                            $('.shopping').animate({right:-230})        
                        }
                    }
                    else if($this.attr('status') === '0') {
                        $this.attr('status','1').siblings().attr('status','0');
                        if($('.shopping').css('right')!='0px'){
                            $('.shopping').animate({right:0})
                        }
                        // 切换内容
                        $('.'+$this.data('content')).css('display', 'block').siblings().css('display', 'none');
                    }
                });

                $('.shopping_l').on('click','.li3',function(){
                    var $div=$('<li/>')
                    $div.css({
                        height:97,
                        background:'#fff'
                    });
                    var cookies = document.cookie;
                        var cookies = document.cookie;
                        var arr = cookies.split('=');
                        if(arr[0] === 'carlist'){
                        var carlist = JSON.parse(arr[1]);
                        }
                        console.log(carlist)
                        var spcImg = document.querySelector('.spcImg');
                        spcImg.innerHTML=carlist.map(function(item){
                            return `
                                <li class="gdlist">
                                    <img src="${item.imgs}"/>
                                    <span>${item.headline}</span>    
                                    <p>
                                        <span>数量：${item.qty}</span>
                                        <span>颜色：${item.color}</span>
                                    </p>
                                </li>
                            `
                        }).join('');
                   
                    if($('.spcImg').height()>=607){
                        $('.spc').css({overflow:'auto'})
                    }
                })

                //将购物车信息存入数据库
                $('.jiesuan').on('click',function(){
                  
                        // 用于保存购物车中的商品信息
                        var carlist = [];
                        var cookies = document.cookie;
                        if(cookies.length){
                            cookies = cookies.split('; ');//['carlist=[{},{}]','username=xxx']
                            cookies.forEach(function(item){
                                var arr = item.split('=');
                                if(arr[0] === 'carlist'){
                                    carlist = JSON.parse(arr[1]);
                                }
                            });
                        }     

                        var currentLi = $('.spcImg').find('li');
                        // 获取当前商品的id
                        var guid = attr[0].id;

                        

                        //判断carlist中是否存在相同商品
                        //判断循环是否跑完
                        for(var i=0;i<carlist.length;i++){
                            if(carlist[i].guid === guid){
                                break;
                            }
                        }

                        if(i===carlist.length){
                            //不存在：创建对象，并且数量为1
                            var goods = {
                                guid:guid,
                                imgs:_imgs,
                                name:_price,
                                headline:_headline,
                                number:_number,
                                color:_color,
                                qty:1
                            }
                            carlist.push(goods);
                            
                        }else{
                            //存在：数量+1
                            carlist[i].qty++;
                        }


                        // 写入cookie
                        document.cookie = 'carlist=' + JSON.stringify(carlist);

                    // var cookies = document.cookie;
                    // var goods = [_imgs,_price,_headline,_number,_color];
                    // document.cookie = JSON.stringify(goods);
                    // console.log(document.cookie);

                });

            }    
        }
        
        xhr.open('get','../data/goodslist.json',true);
        xhr.send();
})