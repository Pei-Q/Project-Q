jQuery(function($){
    $('.mybanner').xCarousel({
        width:750,height:270,
        type:'horizontal',
        imgs:['img/1520314917200.jpg','img/1522288790887.jpg','img/1522309910246.jpg','img/1522633412585.jpg','img/1522733683188.jpg','img/1522746876183.jpg']
    });

    $.ajax({
        type:"get",
        url:"../api/goods.php",
       /* data:{qty:4},*/
        success:function(data){
            var $drug_list=$('.drug_list');
            //console.log(data)
            var $res = JSON.parse(data);
            $res=$res.slice(0,4);
            //console.log($res);
            var $ul=$('<ul/>');
            $ul.addClass('list_f clearfix')
            $res.map(function(item){
                 //console.log(item)
                var $li=$('<li/>');
                    $li.html(`
                        <img src="${item[3]}"  />
                        <h3>${item[2]}</h3>
                        <p>${item[1]}</p>

                    `)

                $ul.append($li);
           
            }); 
            $drug_list.prepend($ul);
            

        }
    });
    
    $.ajax({
        type:"get",
        url:"../api/brand.php",
        success:function(data){
            var $drug_brand=$('.drug_brand');
            console.log(data)
            var $res = JSON.parse(data);
            console.log($res)
            //console.log($res);
            var $ul=$('<ul/>');
            //$ul.addClass('list_f clearfix')
            $res.map(function(item){
                 //console.log(item)
                var $li=$('<li/>');
                    $li.html(`
                       <img src="${item[1]}" />

                    `)
                $li.addClass('fl');
                $li.css({width:97,height:63});
                $li.children('img').css({width:99,height:65});


                $ul.append($li);
           
            }); 
            $drug_brand.prepend($ul);
            

        }
    });

     $.ajax({
        type:"get",
        url:"../api/img.php",
        success:function(data){
            var $drug_list=$('.drug_list');
            console.log(data)
            var $res = JSON.parse(data);
            console.log($res)
            //console.log($res);
            var $ul=$('<ul/>');
            //$ul.addClass('list_f clearfix')
            $res.map(function(item){
                 //console.log(item)
                var $li=$('<li/>');
                    $li.html(`
                       <img src="${item[1]}" />

                    `)
                $ul.addClass('clearfix')
                $li.addClass('fl');
                $ul.append($li);
           
            }); 
            $drug_list.prepend($ul);
            

        }
    });
})