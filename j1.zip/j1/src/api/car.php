<?php
    include 'connect.php';
    $img = isset($_GET['imgs']) ? $_GET['imgs'] : '';
    $price = isset($_GET['price']) ? $_GET['price'] : '';
    $headline = isset($_GET['title']) ? $_GET['title'] : '';
    $number = isset($_GET['number']) ? $_GET['number'] : '';
    //$color = isset($_GET['color']) ? $_GET['color'] : '';

    $sql = "insert into car(imgs,price,tilte,number,color) values('$imgs','$price','$title','$number','$color')";

    // echo $price;

    // // 获取查询结果
    // $result = $conn->query($sql);

    // if ($result) {
    //     echo "ok";
    // } else {
    //     echo "Error: " . $sql . "<br>" . $conn->error;
    // } 

    
    

    // 释放查询内存(销毁)
    $result->free();

    //关闭连接
    $conn->close();
?>   