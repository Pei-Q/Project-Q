jQuery(function($){
    $('.banner').xCarousel({
        width:1263,height:413,
        type:'horizontal',
        imgs:['../img/1522288790887.jpg','../img/1522309910246.jpg','../img/1522633412585.jpg','../img/1522733683188.jpg','../img/1522746876183.jpg']
    });

/*    $.ajax({
            type:"get",
            url:"../api/goodslist.php",
          
            success:function(data){
                var $yaopin=$('.yaopin');
               
                var $res = JSON.parse(data);
                
                var $ul=$('<ul/>');
                
                $res.map(function(item){
                       var $li=$('<li/>');
                 
                        $li.html(`
                            
                                <a href="../html/goods.html"><img class="lazyload"  width="140" height="121"  data-original="${item.img}" src="${item.img}" /></a>
                         
                            <h3>${item.title}</h3>
                            <p>￥${item.peice}</p>

                        `)
                        $ul.append($li);
                         $yaopin.prepend($ul);
                })

            }
  
           
    });*/
                   
               // let img=document.getElementsByClassName('lazyload');

                     //console.log(img)
    
                    $("img.lazyload").lazyload();
                 
                     $("img.lazyload").lazyload({
                            threshold :100
                        });
                     $("img.lazyload").lazyload({
                         effect : "fadeIn"
                        })
                     $("img.lazyload").lazyload({
                        failure_limit :10
                        });
                     $("img.lazyload").lazyload({ 
                        skip_invisible : false
                        });



   
})


document.addEventListener('DOMContentLoaded',function(){
    var yaopin = document.querySelector('.yaopin');
    var pager = document.querySelector('.pager');
    var xhr = new XMLHttpRequest();
    var status = [200,304];
    xhr.onload = function(){
            if(status.includes(xhr.status)){
                //console.log(xhr.responseText)
                var res = JSON.parse(xhr.responseText);
                //console.log(res)
                var ul = document.createElement('ul');
                ul.className = 'goodlists';
                ul.innerHTML=res.map(function(item){
                    //console.log(item)
                    return `
                            <li  class="shangping" data-guid="${item[0]}">
                                <a href="../html/goods.html"><img class="lazyload"  width="140" height="121"  data-original="${item[3]}" src="${item[3]}" /></a>
                         
                                <h3>${item[1]}</h3>
                                <p>￥${item[2]}</p>
                            </li>
                        `
                })
                yaopin.innerText= '';
                yaopin.appendChild(ul);
                //console.log($('.shangping'));

                $('.shangping').on('click',function(){
                    var id = $(this).attr('data-guid');
                    console.log(id);
                    location.href = '../html/goods.html?num='+id;
                })

            }
        }
    xhr.open('post','../api/goods.php',true);
    xhr.setRequestHeader('Content-Type',"application/x-www-form-urlencoded");
    xhr.send(); 
    
})
