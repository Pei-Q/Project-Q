/*
Navicat MySQL Data Transfer

Source Server         : xiaokeai
Source Server Version : 50714
Source Host           : localhost:3306
Source Database       : j1

Target Server Type    : MYSQL
Target Server Version : 50714
File Encoding         : 65001

Date: 2018-04-16 20:51:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for brand
-- ----------------------------
DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of brand
-- ----------------------------
INSERT INTO `brand` VALUES ('1', '../img/1111.jpg');
INSERT INTO `brand` VALUES ('2', '../img/1112.jpg');
INSERT INTO `brand` VALUES ('3', '../img/1113.jpg');
INSERT INTO `brand` VALUES ('4', '../img/1114.jpg');
INSERT INTO `brand` VALUES ('5', '../img/1115.jpg');
INSERT INTO `brand` VALUES ('6', '../img/1116.jpg');
INSERT INTO `brand` VALUES ('7', '../img/1117.jpg');
INSERT INTO `brand` VALUES ('8', '../img/1118.jpg');
INSERT INTO `brand` VALUES ('9', '../img/1119.jpg');
INSERT INTO `brand` VALUES ('10', '../img/1120.jpg');
INSERT INTO `brand` VALUES ('11', '../img/1121.jpg');
INSERT INTO `brand` VALUES ('12', '../img/1122.jpg');

-- ----------------------------
-- Table structure for goodslist
-- ----------------------------
DROP TABLE IF EXISTS `goodslist`;
CREATE TABLE `goodslist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goodslist
-- ----------------------------
INSERT INTO `goodslist` VALUES ('1', '铭德堂上虹精装西洋参云片 1*50g', '139.00', '../img/111.jpg', null);
INSERT INTO `goodslist` VALUES ('2', ' 力度伸 维生素C泡腾片 30片', '4448.00', '../img/112.jpg', null);
INSERT INTO `goodslist` VALUES ('3', '双立人中式料理套装', '5999.00', '../img/113.jpg', null);
INSERT INTO `goodslist` VALUES ('4', '鹰牌花旗参胶囊', '228.00', '../img/114.jpg', null);
INSERT INTO `goodslist` VALUES ('5', '敖东 安神补脑液 10支*5盒', '98.00', '../img/115.jpg', null);
INSERT INTO `goodslist` VALUES ('6', ' 力度伸 维生素C泡腾片 30片', '90.00', '../img/116.jpg', null);
INSERT INTO `goodslist` VALUES ('7', '21金维他 多维元素片(21)', '65.00', '../img/117.jpg', null);
INSERT INTO `goodslist` VALUES ('8', '三精 葡萄糖酸钙口服溶液 12支', '12.00', '../img/118.jpg', null);

-- ----------------------------
-- Table structure for img
-- ----------------------------
DROP TABLE IF EXISTS `img`;
CREATE TABLE `img` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of img
-- ----------------------------
INSERT INTO `img` VALUES ('1', '../img/11.jpg');
INSERT INTO `img` VALUES ('2', '../img/12.jpg');
INSERT INTO `img` VALUES ('3', '../img/13.jpg');

-- ----------------------------
-- Table structure for liebiaoye
-- ----------------------------
DROP TABLE IF EXISTS `liebiaoye`;
CREATE TABLE `liebiaoye` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `peice` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of liebiaoye
-- ----------------------------
INSERT INTO `liebiaoye` VALUES ('1', '../img/221.jpg', '1111', '维力青 恩替卡韦分散片 0.5mg*7片 ');
INSERT INTO `liebiaoye` VALUES ('2', '../img/222.jpg', '222', '博路定 恩替卡韦片 7片/盒');
INSERT INTO `liebiaoye` VALUES ('3', '../img/223.jpg', '333', '润众 恩替卡韦分散片 7片');
INSERT INTO `liebiaoye` VALUES ('4', '../img/224.jpg', '444', '【雷易得】 恩替卡韦分散片 （0.5毫克 7片装）');
INSERT INTO `liebiaoye` VALUES ('5', '../img/225.jpg', '555', '999 华蟾素片 30片');
INSERT INTO `liebiaoye` VALUES ('6', '../img/226.jpg', '666', '名正 阿德福韦酯胶囊 10mg*14粒 江苏正大天晴');
INSERT INTO `liebiaoye` VALUES ('7', '../img/227.jpg', '777', '丁贺 阿德福韦酯片 14片');
INSERT INTO `liebiaoye` VALUES ('8', '../img/228.jpg', '8784', '◆健甘灵 拉米夫定片 14片 湖南千金湘江药业 ');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of users
-- ----------------------------
SET FOREIGN_KEY_CHECKS=1;
